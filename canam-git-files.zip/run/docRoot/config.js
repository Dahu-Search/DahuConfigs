const configs = {
    googleclientid : "232366777286-pv600b8ckq0119iomh31ejtsnst128lf.apps.googleusercontent.com",
    debug : "false",
    appname : "canam Search",
    signin : "Google"

};
