const theme = {
    overrides: {
        MuiSvgIcon: {
            root: {
                verticalAlign:'middle',
            },
        },
        MuiTooltip: {
            tooltip: {
                fontSize: 12,
            }

        }
    },
    typography: {
        useNextVariants: true,
        fontSize: 12,
    },
    palette: {
        primary: {
            main:'#5577fb',
        },
        secondary: {
            main:'#858FA9',
        },

        error: {
            main:'#ff0000',
        },
        // Used by `getContrastText()` to maximize the contrast between the background and
        // the text.
        contrastThreshold: 3,
        // Used to shift a color's luminance by approximately
        // two indexes within its tonal palette.
        // E.g., shift from Red 500 to Red 300 or Red 700.
        tonalOffset: 0.2,
    },
    def:{
        dahuLogo: "/images/themeImages/dahu-small-green.png",
        brandLogo: "/images/themeImages/AODocs.png",
        fullScreen: "/images/themeImages/AODocs-fullscreen.jpg",
        horizScreen: "/images/themeImages/AODocs-horiz-grey.jpg",
        vertScreen: "/images/themeImages/AODocs-vert-grey.jpg",

    }
};
